import "dart:ui";
import "package:flutter/material.dart";

class ColorCode {
  ColorCode._();
  // static Color orange = const Color(0xffDD4C00);
  // static Color grey = const Color(0xff424242);
  // static Color lightgrey = const Color(0xffd7dbde);
  // static Color black = Colors.black;
  // static Color white = Colors.white;
  static Color orange = const Color(0xff3F66FF);
  static Color grey = const Color(0xff201568);
  static Color lightgrey = const Color(0xffBEE1FF);
  static Color black = const Color(0xff201568);
  static Color white = Colors.white;
}
